### Hexlet tests and linter status:
[![Actions Status](https://github.com/aearea/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/aearea/python-project-49/actions)